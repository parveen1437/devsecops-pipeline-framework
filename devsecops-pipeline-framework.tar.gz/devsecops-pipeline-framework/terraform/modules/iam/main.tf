# ---------------------------------------------------
# IAM Module - Least-Privilege Enforcement (Gate 3)
# ---------------------------------------------------
# This module creates strictly scoped IAM roles for
# EKS workloads using IRSA (IAM Roles for Service Accounts).
# Every role follows the principle of least privilege.
# ---------------------------------------------------

variable "project_name" {
  type    = string
  default = "devsecops"
}

variable "environment" {
  type    = string
  default = "dev"
}

variable "oidc_provider_arn" {
  description = "EKS OIDC provider ARN for IRSA"
  type        = string
}

variable "oidc_provider_url" {
  description = "EKS OIDC provider URL (without https://)"
  type        = string
}

locals {
  common_tags = {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "terraform"
    SecurityGate = "gate-3-iam-least-privilege"
  }
}

# ---------------------------------------------------
# Example: App Service Role (IRSA)
# Only allows reading from a specific S3 bucket
# and reading secrets from Secrets Manager
# ---------------------------------------------------
resource "aws_iam_role" "app_service" {
  name = "${var.project_name}-${var.environment}-app-service-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = var.oidc_provider_arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${var.oidc_provider_url}:sub" = "system:serviceaccount:app:app-service"
          "${var.oidc_provider_url}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "app_service" {
  name = "${var.project_name}-${var.environment}-app-service-policy"
  role = aws_iam_role.app_service.id

  # LEAST PRIVILEGE: Only specific S3 bucket + specific secrets
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "S3ReadOnly"
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          "arn:aws:s3:::${var.project_name}-${var.environment}-app-data",
          "arn:aws:s3:::${var.project_name}-${var.environment}-app-data/*"
        ]
      },
      {
        Sid    = "SecretsManagerReadOnly"
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue"
        ]
        Resource = [
          "arn:aws:secretsmanager:*:*:secret:${var.project_name}/${var.environment}/app-*"
        ]
      }
    ]
  })
}

# ---------------------------------------------------
# Example: CI/CD Pipeline Role
# Only allows pushing images to ECR and updating EKS
# ---------------------------------------------------
resource "aws_iam_role" "cicd_pipeline" {
  name = "${var.project_name}-${var.environment}-cicd-pipeline-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = var.oidc_provider_arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${var.oidc_provider_url}:sub" = "system:serviceaccount:ci-cd:pipeline-runner"
          "${var.oidc_provider_url}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "cicd_pipeline" {
  name = "${var.project_name}-${var.environment}-cicd-pipeline-policy"
  role = aws_iam_role.cicd_pipeline.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ECRPush"
        Effect = "Allow"
        Action = [
          "ecr:GetAuthorizationToken",
          "ecr:BatchCheckLayerAvailability",
          "ecr:PutImage",
          "ecr:InitiateLayerUpload",
          "ecr:UploadLayerPart",
          "ecr:CompleteLayerUpload"
        ]
        Resource = "*"
      },
      {
        Sid    = "EKSDescribe"
        Effect = "Allow"
        Action = [
          "eks:DescribeCluster"
        ]
        Resource = "arn:aws:eks:*:*:cluster/${var.project_name}-${var.environment}-eks"
      }
    ]
  })
}

# ---------------------------------------------------
# IAM Access Analyzer (for continuous auditing)
# ---------------------------------------------------
resource "aws_accessanalyzer_analyzer" "main" {
  analyzer_name = "${var.project_name}-${var.environment}-access-analyzer"
  type          = "ACCOUNT"

  tags = local.common_tags
}

# ---------------------------------------------------
# Deny policy: Block overly permissive actions
# Attach to organizational boundary
# ---------------------------------------------------
resource "aws_iam_policy" "deny_dangerous_actions" {
  name        = "${var.project_name}-${var.environment}-deny-dangerous"
  description = "Deny dangerous IAM actions that could lead to privilege escalation"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DenyIAMWildcard"
        Effect = "Deny"
        Action = [
          "iam:CreateUser",
          "iam:CreateAccessKey",
          "iam:AttachUserPolicy",
          "iam:PutUserPolicy"
        ]
        Resource = "*"
        Condition = {
          StringNotEquals = {
            "aws:PrincipalTag/Role" = "admin"
          }
        }
      },
      {
        Sid    = "DenyS3PublicAccess"
        Effect = "Deny"
        Action = [
          "s3:PutBucketPolicy",
          "s3:PutBucketAcl",
          "s3:PutObjectAcl"
        ]
        Resource = "*"
        Condition = {
          StringEquals = {
            "s3:x-amz-acl" = "public-read"
          }
        }
      }
    ]
  })

  tags = local.common_tags
}

# ---------------------------------------------------
# Outputs
# ---------------------------------------------------
output "app_service_role_arn" {
  value = aws_iam_role.app_service.arn
}

output "cicd_pipeline_role_arn" {
  value = aws_iam_role.cicd_pipeline.arn
}

output "access_analyzer_arn" {
  value = aws_accessanalyzer_analyzer.main.arn
}
