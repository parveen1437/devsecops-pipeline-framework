#!/bin/bash
# ---------------------------------------------------
# Pre-Commit Secret Scanner (Gate 5)
# ---------------------------------------------------
# Prevents hardcoded credentials from being committed.
# Install: cp scripts/secret-scanner.sh .git/hooks/pre-commit
# ---------------------------------------------------

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

echo "🔒 Gate 5: Scanning staged files for secrets..."

SECRETS_FOUND=0

# Get list of staged files
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)

if [ -z "$STAGED_FILES" ]; then
    echo -e "${GREEN}No staged files to scan.${NC}"
    exit 0
fi

# ---------------------------------------------------
# Pattern 1: AWS Access Keys
# ---------------------------------------------------
for FILE in $STAGED_FILES; do
    if [ -f "$FILE" ]; then
        # AWS Access Key ID
        if grep -nP 'AKIA[0-9A-Z]{16}' "$FILE" 2>/dev/null; then
            echo -e "${RED}❌ AWS Access Key ID found in: $FILE${NC}"
            SECRETS_FOUND=$((SECRETS_FOUND + 1))
        fi

        # AWS Secret Access Key (40 char base64)
        if grep -nP '[^A-Za-z0-9/+=][A-Za-z0-9/+=]{40}[^A-Za-z0-9/+=]' "$FILE" 2>/dev/null | grep -i 'secret\|key\|aws' 2>/dev/null; then
            echo -e "${RED}❌ Possible AWS Secret Key found in: $FILE${NC}"
            SECRETS_FOUND=$((SECRETS_FOUND + 1))
        fi
    fi
done

# ---------------------------------------------------
# Pattern 2: Generic secrets and tokens
# ---------------------------------------------------
PATTERNS=(
    'password\s*=\s*["\x27][^\s]{8,}'
    'api_key\s*=\s*["\x27][^\s]{8,}'
    'secret\s*=\s*["\x27][^\s]{8,}'
    'token\s*=\s*["\x27][^\s]{8,}'
    'private_key\s*=\s*["\x27][^\s]{8,}'
    'BEGIN (RSA |DSA |EC )?PRIVATE KEY'
    'BEGIN OPENSSH PRIVATE KEY'
)

for FILE in $STAGED_FILES; do
    if [ -f "$FILE" ]; then
        # Skip binary files and known safe files
        case "$FILE" in
            *.png|*.jpg|*.gif|*.ico|*.woff|*.woff2|*.lock|*.sum)
                continue
                ;;
        esac

        for PATTERN in "${PATTERNS[@]}"; do
            if grep -nPi "$PATTERN" "$FILE" 2>/dev/null; then
                echo -e "${RED}❌ Potential secret (pattern: $PATTERN) in: $FILE${NC}"
                SECRETS_FOUND=$((SECRETS_FOUND + 1))
            fi
        done
    fi
done

# ---------------------------------------------------
# Pattern 3: .env files should never be committed
# ---------------------------------------------------
for FILE in $STAGED_FILES; do
    case "$FILE" in
        .env|.env.*|*.env)
            echo -e "${RED}❌ Environment file should not be committed: $FILE${NC}"
            echo "   Add it to .gitignore instead."
            SECRETS_FOUND=$((SECRETS_FOUND + 1))
            ;;
    esac
done

# ---------------------------------------------------
# Result
# ---------------------------------------------------
echo ""
if [ "$SECRETS_FOUND" -gt 0 ]; then
    echo -e "${RED}=================================================${NC}"
    echo -e "${RED}BLOCKED: $SECRETS_FOUND potential secret(s) found${NC}"
    echo -e "${RED}=================================================${NC}"
    echo ""
    echo "How to fix:"
    echo "  1. Remove the secret from the file"
    echo "  2. Use AWS Secrets Manager or KMS instead"
    echo "  3. Add sensitive files to .gitignore"
    echo "  4. Run: git reset HEAD <file> to unstage"
    echo ""
    echo "To bypass (NOT recommended):"
    echo "  git commit --no-verify"
    exit 1
else
    echo -e "${GREEN}✅ Gate 5 PASSED - No secrets detected${NC}"
    exit 0
fi
