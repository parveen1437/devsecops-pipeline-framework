#!/bin/bash
# ---------------------------------------------------
# IAM Least-Privilege Audit Script (Gate 3)
# ---------------------------------------------------
# Scans AWS IAM roles and policies for:
#   - Wildcard (*) permissions
#   - Overly broad resource access
#   - Unused roles and access keys
#   - MFA enforcement status
# ---------------------------------------------------

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "================================================="
echo "  IAM Least-Privilege Audit"
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "================================================="
echo ""

ISSUES_FOUND=0

# ---------------------------------------------------
# Check 1: Roles with wildcard actions
# ---------------------------------------------------
echo -e "${YELLOW}[CHECK 1] Scanning for roles with wildcard (*) actions...${NC}"
ROLES=$(aws iam list-roles --query 'Roles[?starts_with(RoleName, `devsecops`)].RoleName' --output text)

for ROLE in $ROLES; do
    POLICIES=$(aws iam list-attached-role-policies --role-name "$ROLE" --query 'AttachedPolicies[].PolicyArn' --output text)
    INLINE=$(aws iam list-role-policies --role-name "$ROLE" --query 'PolicyNames[]' --output text)

    for POLICY_ARN in $POLICIES; do
        VERSION=$(aws iam get-policy --policy-arn "$POLICY_ARN" --query 'Policy.DefaultVersionId' --output text)
        DOCUMENT=$(aws iam get-policy-version --policy-arn "$POLICY_ARN" --version-id "$VERSION" --query 'PolicyVersion.Document' --output json)

        if echo "$DOCUMENT" | grep -q '"Action": "\*"'; then
            echo -e "  ${RED}CRITICAL: Role '$ROLE' has wildcard Action via policy $POLICY_ARN${NC}"
            ISSUES_FOUND=$((ISSUES_FOUND + 1))
        fi

        if echo "$DOCUMENT" | grep -q '"Resource": "\*"'; then
            ACTION=$(echo "$DOCUMENT" | python3 -c "import sys,json; d=json.load(sys.stdin); [print(s.get('Action','')) for s in d.get('Statement',[])]" 2>/dev/null || echo "unknown")
            echo -e "  ${YELLOW}WARNING: Role '$ROLE' has wildcard Resource (Action: $ACTION)${NC}"
        fi
    done

    for POLICY_NAME in $INLINE; do
        DOCUMENT=$(aws iam get-role-policy --role-name "$ROLE" --policy-name "$POLICY_NAME" --query 'PolicyDocument' --output json)

        if echo "$DOCUMENT" | grep -q '"Action": "\*"'; then
            echo -e "  ${RED}CRITICAL: Role '$ROLE' has wildcard Action in inline policy '$POLICY_NAME'${NC}"
            ISSUES_FOUND=$((ISSUES_FOUND + 1))
        fi
    done
done
echo ""

# ---------------------------------------------------
# Check 2: Access keys older than 90 days
# ---------------------------------------------------
echo -e "${YELLOW}[CHECK 2] Scanning for stale access keys (>90 days)...${NC}"
USERS=$(aws iam list-users --query 'Users[].UserName' --output text)

for USER in $USERS; do
    KEYS=$(aws iam list-access-keys --user-name "$USER" --query 'AccessKeyMetadata[?Status==`Active`].[AccessKeyId,CreateDate]' --output text)

    while IFS=$'\t' read -r KEY_ID CREATE_DATE; do
        if [ -n "$KEY_ID" ]; then
            DAYS_OLD=$(( ($(date +%s) - $(date -d "$CREATE_DATE" +%s)) / 86400 ))
            if [ "$DAYS_OLD" -gt 90 ]; then
                echo -e "  ${RED}CRITICAL: User '$USER' has access key $KEY_ID that is $DAYS_OLD days old${NC}"
                ISSUES_FOUND=$((ISSUES_FOUND + 1))
            fi
        fi
    done <<< "$KEYS"
done
echo ""

# ---------------------------------------------------
# Check 3: Users without MFA
# ---------------------------------------------------
echo -e "${YELLOW}[CHECK 3] Checking MFA enforcement...${NC}"
for USER in $USERS; do
    MFA=$(aws iam list-mfa-devices --user-name "$USER" --query 'MFADevices' --output text)
    if [ -z "$MFA" ]; then
        echo -e "  ${RED}CRITICAL: User '$USER' does not have MFA enabled${NC}"
        ISSUES_FOUND=$((ISSUES_FOUND + 1))
    fi
done
echo ""

# ---------------------------------------------------
# Check 4: IAM Access Analyzer findings
# ---------------------------------------------------
echo -e "${YELLOW}[CHECK 4] Checking IAM Access Analyzer findings...${NC}"
ANALYZERS=$(aws accessanalyzer list-analyzers --query 'analyzers[].arn' --output text)

for ANALYZER in $ANALYZERS; do
    FINDINGS=$(aws accessanalyzer list-findings --analyzer-arn "$ANALYZER" --query 'findings[?status==`ACTIVE`].{Resource: resource, Type: resourceType}' --output json)
    FINDING_COUNT=$(echo "$FINDINGS" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")

    if [ "$FINDING_COUNT" -gt 0 ]; then
        echo -e "  ${YELLOW}WARNING: $FINDING_COUNT active Access Analyzer findings${NC}"
        echo "$FINDINGS" | python3 -c "
import sys, json
findings = json.load(sys.stdin)
for f in findings[:5]:
    print(f'    - {f[\"Type\"]}: {f[\"Resource\"]}')
if len(findings) > 5:
    print(f'    ... and {len(findings)-5} more')
" 2>/dev/null || true
    else
        echo -e "  ${GREEN}No active Access Analyzer findings${NC}"
    fi
done
echo ""

# ---------------------------------------------------
# Summary
# ---------------------------------------------------
echo "================================================="
if [ "$ISSUES_FOUND" -gt 0 ]; then
    echo -e "${RED}AUDIT COMPLETE: $ISSUES_FOUND issues found${NC}"
    echo "Review and remediate before next deployment."
    exit 1
else
    echo -e "${GREEN}AUDIT COMPLETE: No critical issues found ✅${NC}"
    exit 0
fi
